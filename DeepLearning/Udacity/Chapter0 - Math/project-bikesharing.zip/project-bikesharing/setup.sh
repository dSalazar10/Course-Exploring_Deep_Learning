#!/bin/bash

echo "Download your JWT by clicking here:"
echo "https://project-assistant.udacity.com/auth_tokens/new"
echo
echo "Once you've downloaded your JWT, copy the contents into the editor tab titled "jwt" (The file is: /home/workspace/first-neural-network/jwt)"
echo "After that step, you can run the project assistant. To do that, first go to the first-neural-network directory ('cd first-neural-network') and then submit your project with : udacity submit first-neural-network"